package mindustry.graphics;

public class EnvRenderers{

    public static void init(){

    }
}
