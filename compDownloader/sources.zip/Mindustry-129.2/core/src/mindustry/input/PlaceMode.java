package mindustry.input;

public enum PlaceMode{
    none, breaking, placing, schematicSelect
}
